
# Create realistic emissions reduction data for different strategies based on research
# This will help inform the simulator with actual ranges from literature

strategies_data = {
    'Strategy': [
        'Fuel Switch (Fuel Oil to Gas)',
        'Fuel Switch (Natural Gas to CBG)',
        'Electrification 25%',
        'Electrification 50%',
        'Electrification 75%',
        'Electrification 100%',
        'Green Hydrogen',
        'Blue Hydrogen',
        'Using Renewables',
        'Nature Based Solutions'
    ],
    'Emission Reduction (%)': [
        '15-25%',
        '30-40%',
        '9-12%',
        '18-24%',
        '27-36%',
        '36-48%',
        '90-95%',
        '50-70%',
        '17-50%',
        '5-15%'
    ],
    'Primary Scope': [
        'Scope 1',
        'Scope 1',
        'Scope 1 & 2',
        'Scope 1 & 2',
        'Scope 1 & 2',
        'Scope 1 & 2',
        'Scope 1',
        'Scope 1',
        'Scope 2',
        'Scope 1 & 3'
    ],
    'Implementation Timeline': [
        '1-2 years',
        '2-3 years',
        '2-3 years',
        '3-5 years',
        '5-7 years',
        '7-10 years',
        '3-5 years',
        '2-4 years',
        '2-3 years',
        '2-5 years'
    ],
    'Key Notes': [
        'Switch from heavy fuel oil to natural gas in furnaces and boilers',
        'CBG from waste biomass - SATAT scheme in India',
        'Partial electrification of heaters, boilers with renewable electricity',
        'Medium-scale electrification deployment',
        'Large-scale electrification across refinery',
        'Complete electrification - requires grid decarbonization',
        'Hydrogen from renewable electricity for refinery processes',
        'Hydrogen with CCS - depends on capture rate and methane leakage',
        'On-site solar/wind or grid renewable electricity purchase',
        'Carbon offsets through reforestation, wetlands, soil sequestration'
    ]
}

import pandas as pd
df = pd.DataFrame(strategies_data)
print(df.to_string(index=False))
print("\n" + "="*80)
print("Data prepared for carbon reduction simulator")
