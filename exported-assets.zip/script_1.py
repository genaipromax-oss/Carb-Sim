
# Create sample baseline emissions data for different refinery sizes and locations
# Based on research, Indian refineries emit around 21.5-24 MMTCO2e total
# Individual refineries vary based on size

import pandas as pd

# Create realistic refinery baseline data
refinery_baseline_data = {
    'Location': [
        'Gujarat (Vadodara)',
        'Maharashtra (Mumbai)',
        'Uttar Pradesh (Mathura)',
        'Odisha (Paradip)',
        'Tamil Nadu (Chennai)'
    ],
    'Capacity (MMTPA)': [13.7, 12.0, 8.0, 15.0, 10.5],
    'Baseline Scope 1 (MTCO2e)': [4500000, 3900000, 2600000, 4900000, 3400000],
    'Baseline Scope 2 (MTCO2e)': [190000, 165000, 110000, 205000, 145000],
    'Total Baseline (MTCO2e)': [4690000, 4065000, 2710000, 5105000, 3545000],
    'Primary Products': [
        'Diesel, Gasoline, LPG',
        'Diesel, Naphtha, ATF',
        'Diesel, Gasoline, LPG',
        'Diesel, Gasoline, Petrochemicals',
        'Diesel, Gasoline, ATF'
    ]
}

df_baseline = pd.DataFrame(refinery_baseline_data)
print("INDIAN REFINERY BASELINE EMISSIONS DATA")
print("="*80)
print(df_baseline.to_string(index=False))
print("\n" + "="*80)
print(f"Total Baseline Emissions Across 5 Sites: {df_baseline['Total Baseline (MTCO2e)'].sum():,.0f} MTCO2e")
print(f"Average per Site: {df_baseline['Total Baseline (MTCO2e)'].mean():,.0f} MTCO2e")
print(f"Scope 1 represents ~96% of total emissions (consistent with IndianOil data)")
