
# Calculate emission reductions for different strategy combinations
# Using mid-range values from research

import json

# Define emission reduction percentages (using mid-range values)
reduction_factors = {
    'fuel_oil_to_gas': 0.20,  # 20% reduction
    'gas_to_cbg': 0.35,  # 35% reduction
    'electrification_25': 0.105,  # 10.5% reduction
    'electrification_50': 0.21,  # 21% reduction
    'electrification_75': 0.315,  # 31.5% reduction
    'electrification_100': 0.42,  # 42% reduction
    'green_hydrogen': 0.925,  # 92.5% reduction
    'blue_hydrogen': 0.60,  # 60% reduction
    'renewables': 0.335,  # 33.5% reduction (mid-range)
    'nature_based': 0.10  # 10% reduction (offset credits)
}

# Sample baseline for Gujarat refinery
baseline_emissions = 4690000  # MTCO2e

# Calculate reductions for individual strategies
strategy_impacts = {}
for strategy, factor in reduction_factors.items():
    reduction = baseline_emissions * factor
    future_emissions = baseline_emissions - reduction
    strategy_impacts[strategy] = {
        'reduction_mtco2e': round(reduction, 0),
        'reduction_percent': round(factor * 100, 1),
        'future_emissions': round(future_emissions, 0)
    }

# Display results
print("EMISSION REDUCTION SCENARIOS - Gujarat Refinery")
print(f"Baseline Emissions: {baseline_emissions:,.0f} MTCO2e")
print("="*80)
print(f"{'Strategy':<30} {'Reduction (MTCO2e)':<20} {'Reduction %':<15} {'Future Emissions'}")
print("="*80)

strategy_names = {
    'fuel_oil_to_gas': 'Fuel Oil → Gas',
    'gas_to_cbg': 'Natural Gas → CBG',
    'electrification_25': 'Electrification 25%',
    'electrification_50': 'Electrification 50%',
    'electrification_75': 'Electrification 75%',
    'electrification_100': 'Electrification 100%',
    'green_hydrogen': 'Green Hydrogen',
    'blue_hydrogen': 'Blue Hydrogen',
    'renewables': 'Using Renewables',
    'nature_based': 'Nature Based Solutions'
}

for strategy, name in strategy_names.items():
    impact = strategy_impacts[strategy]
    print(f"{name:<30} {impact['reduction_mtco2e']:>15,.0f}    {impact['reduction_percent']:>10.1f}%    {impact['future_emissions']:>15,.0f}")

print("\n" + "="*80)
print("Note: Reductions calculated individually. Combined strategies may have synergies or limitations.")
