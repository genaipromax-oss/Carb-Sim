
# Create a comprehensive cost and implementation summary table
import pandas as pd

implementation_data = {
    'Strategy': [
        'Fuel Oil → Gas',
        'Gas → CBG',
        'Electrification 25%',
        'Electrification 50%',
        'Electrification 75%',
        'Electrification 100%',
        'Green Hydrogen',
        'Blue Hydrogen',
        'Renewables',
        'Nature Based',
        'Carbon Capture (CCS)'
    ],
    'Emission Reduction': [
        '15-25%',
        '30-40%',
        '9-12%',
        '18-24%',
        '27-36%',
        '36-48%',
        '90-95%',
        '50-70%',
        '17-50%',
        '5-15%',
        '85-95%'
    ],
    'Cost per tCO2': [
        '$15-30',
        '$20-40',
        '$50-100',
        '$60-120',
        '$80-150',
        '$100-200',
        '$70-175',
        '$40-100',
        '$20-60',
        '$10-30',
        '$40-120'
    ],
    'Timeline': [
        '1-2 years',
        '2-3 years',
        '2-3 years',
        '3-5 years',
        '5-7 years',
        '7-10 years',
        '3-5 years',
        '2-4 years',
        '2-3 years',
        '2-5 years',
        '3-5 years'
    ],
    'Capital Investment': [
        'Low-Medium',
        'Medium',
        'Medium-High',
        'High',
        'Very High',
        'Very High',
        'Very High',
        'High',
        'Medium',
        'Low',
        'Very High'
    ],
    'Maturity Level': [
        'Mature',
        'Developing',
        'Emerging',
        'Emerging',
        'Early Stage',
        'Early Stage',
        'Developing',
        'Emerging',
        'Mature',
        'Mature',
        'Developing'
    ]
}

df_impl = pd.DataFrame(implementation_data)

# Save to CSV
df_impl.to_csv('implementation_guide.csv', index=False)

print("DECARBONIZATION STRATEGY IMPLEMENTATION GUIDE")
print("="*100)
print(df_impl.to_string(index=False))
print("\n" + "="*100)
print("\nKEY INSIGHTS:")
print("• Green Hydrogen offers highest reduction (90-95%) but at $70-175/tCO2")
print("• CBG offers strong mid-range reduction (30-40%) at competitive cost ($20-40/tCO2)")
print("• Nature-based solutions provide lowest cost offsets ($10-30/tCO2)")
print("• Renewables can achieve 17-50% reduction with medium investment")
print("• Combination strategies can achieve 60-80% total reduction by 2040")
print("\nFile saved: implementation_guide.csv")
